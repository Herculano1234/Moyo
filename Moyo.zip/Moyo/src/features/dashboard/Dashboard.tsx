﻿import React from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Jan", pacientes: 400, urgencias: 24 },
  { name: "Fev", pacientes: 300, urgencias: 13 },
  { name: "Mar", pacientes: 250, urgencias: 16 },
  { name: "Abr", pacientes: 278, urgencias: 22 },
  { name: "Mai", pacientes: 189, urgencias: 18 },
  { name: "Jun", pacientes: 239, urgencias: 20 },
];

export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 text-moyo-primary dark:text-moyo-primary">
        VisÃ£o Geral
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4">
          <h2 className="font-semibold mb-2 text-gray-700 dark:text-gray-200">Atendimentos Mensais</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={data}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="pacientes" stroke="#6366F1" strokeWidth={2} />
              <Line type="monotone" dataKey="urgencias" stroke="#F472B6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 flex flex-col justify-center items-center">
          <span className="text-3xl font-bold text-moyo-primary dark:text-moyo-primary mb-2">
            1.234
          </span>
          <span className="text-gray-700 dark:text-gray-300">Pacientes Atendidos Este Ano</span>
        </div>
        {/* Adicione outros cards/grÃ¡ficos conforme crescer o sistema */}
      </div>
    </div>
  );
}
